<?php

if(isset($_FILES['gamuza_screenshot'])){

		print("Success! \n");
    print("tmpName: " . $_FILES['gamuza_screenshot']['tmp_name'] . " \n");
    print("size: " . $_FILES['gamuza_screenshot']['size'] . " \n");
    print("mime: " . $_FILES['gamuza_screenshot']['type'] . " \n");
    print("name: " . $_FILES['gamuza_screenshot']['name'] . " \n");

    move_uploaded_file($_FILES['gamuza_screenshot']['tmp_name'], "images/" . $_FILES['gamuza_screenshot']['name']);

}else{

	print("Error: " . $_FILES['gamuza_screenshot']['error'] . " \n");

}

if(isset($_POST['number'])){
	print("Image uploaded Number:". $_POST['number'] ." \n");
}


?>
